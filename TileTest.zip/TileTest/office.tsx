<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="office" tilewidth="32" tileheight="32" tilecount="848" columns="16">
 <image source="../../Documents/VCF Tilesets/tilesets/assets/Modern_Office_Revamped_v1.2/Modern_Office_32x32.png" width="512" height="1696"/>
</tileset>
